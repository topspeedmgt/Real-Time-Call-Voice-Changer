# Real-Time Call Voice Changer

A browser-based real-time voice changer intended to be connected to real telephone calls through a programmable telephony provider.

**Status: early development. Nothing in this repository places or receives real phone calls yet.**

## What exists today

- `web-prototype/index.html`: a single-file browser voice changer (Web Audio API). It processes your microphone live and plays it back. It is not connected to any phone call.

## Goals

- Real-time voice processing in the browser (Web Audio API, AudioWorklet).
- Male and female voice profiles with adjustable pitch, formant, tone, speed, EQ and noise suppression.
- Outgoing and incoming phone calls through a VoIP provider, with processed audio sent to the other party.
- Works on iPhone Safari, Android and desktop browsers.
- Free-first: free-tier hosting and database. No paid service is enabled without the owner's explicit approval.

## Principles

- Every feature shown in the UI must either work or be clearly labelled "not implemented yet".
- No secrets in this repository. See `.env.example`.
- Call audio is never recorded or stored by default.
- Voices of real people are never cloned without their authorization.

## Documentation

- [Development log](docs/DEVELOPMENT_LOG.md)
- [Telephony findings](docs/TELEPHONY_FINDINGS.md)
- [Proposed architecture](docs/ARCHITECTURE.md)

The working name is "Real-Time Call Voice Changer" until the owner chooses another.
