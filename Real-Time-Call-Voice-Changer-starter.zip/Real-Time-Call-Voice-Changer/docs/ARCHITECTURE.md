# Proposed architecture (not yet built or validated)

Browser mic -> AudioWorklet DSP -> WebRTC/SIP client -> telephony provider -> phone network.
Incoming calls: provider webhook -> signaling backend -> browser client; reverse audio path.

- Frontend: Next.js, React, TypeScript, Web Audio API + AudioWorklet. Free hosting candidate: Vercel free tier (verify terms).
- Backend: Node/TypeScript for webhooks and call control. Vercel serverless is not suitable for persistent media streams.
- Media server (if the provider SDK cannot take processed audio): separate always-on host. A free tier with no sleeping must be verified before choosing one.
- Database/auth: Supabase free tier (verify limits).
- Voice engine: start with DSP (formant-preserving pitch shift, EQ, noise suppression); keep an interface so an AI speech-to-speech engine can be added later.
- Privacy: no call audio stored by default; webhook signature verification; rate limiting.

Latency targets and measurements: to be added after the audio engine exists.
