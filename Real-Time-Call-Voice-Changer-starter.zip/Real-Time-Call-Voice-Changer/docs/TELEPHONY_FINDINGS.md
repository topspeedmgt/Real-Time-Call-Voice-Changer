# Telephony findings

Only items marked "verified" were confirmed from the cited source. Everything else is unverified.

## TextPlus
- Verified: TextPlus publishes a number-portability guide for moving a number out. The name on the port request must match the TextPlus account, the number must be active, and a PIN should not be placed on the port request because TextPlus has no PIN. Source: help.textplus.com, "Number Portability: A Guide for textPlus Users".
- Not found: any TextPlus SIP, VoIP, programmable-calling API or call-forwarding integration. This does not prove none exists. Ask TextPlus support.
- Do not port, cancel or change the TextPlus number without explicit owner approval.

## Providers
- Verified: Twilio and Telnyx both document porting existing numbers in (Twilio: "port host" docs; Telnyx: numbers porting docs).
- Unverified, must check before relying on them: port eligibility of this specific number, trial limits (for example verified-numbers-only), per-minute and number costs, whether the provider's browser SDK can send custom processed audio into a call, and Media Streams or equivalent for a server-side audio bridge.

## Browser limitation
- A web page cannot intercept audio from a normal phone call or from the TextPlus app. Processing must sit inside a call path the app controls (browser WebRTC client or server media bridge).
