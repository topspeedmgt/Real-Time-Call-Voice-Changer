# Development log

## Completed
- Browser voice-changer prototype (`web-prototype/index.html`): live mic input, pitch shift, robot effect, echo, presets, waveform. Not yet tested by the owner on a device.

## Pending
- Next.js + TypeScript app shell with mobile-first dashboard, dial pad and call screens.
- AudioWorklet voice engine with male and female profiles, formant control, noise suppression, latency measurement.
- Telephony provider selection, number porting decision, media server.
- Supabase auth and settings, deployment, security tests.

## Blocked / needs owner input
- GitHub connection in the chat had read-only access, so commits were pushed manually.
- Telephony: any paid service, number purchase, or porting of the existing TextPlus number needs explicit owner approval.
- Real call tests need the owner's phone and an approved test number.
